<?php
namespace app\index\model;

use think\Model;

class Food extends Model{
    
}