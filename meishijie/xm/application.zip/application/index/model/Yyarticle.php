<?php
namespace app\index\model;

use think\Model;

class Yyarticle extends Model{
    
}