<?php
namespace app\index\model;

use think\Model;

class Cooking extends Model{
    
    
}