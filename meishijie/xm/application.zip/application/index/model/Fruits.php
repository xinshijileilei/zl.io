<?php
namespace app\index\model;

use think\Model;

class Fruits extends Model{
    
}