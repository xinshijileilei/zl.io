<?php
namespace app\index\model;

use think\Model;

class Assist extends Model{
    
}