<?php
namespace app\index\model;

use think\Model;

class Usertype extends Model{
    
    
}