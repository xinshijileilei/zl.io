<?php
namespace app\index\model;

use think\Model;

class Nuts extends Model{
    
}