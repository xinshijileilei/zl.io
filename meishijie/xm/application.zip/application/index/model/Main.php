<?php
namespace app\index\model;

use think\Model;

class Main extends Model{
    
}