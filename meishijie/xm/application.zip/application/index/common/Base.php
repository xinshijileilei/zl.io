<?php
namespace app\index\common;

use think\Controller;

class Base extends \think\Controller
{

    
}
