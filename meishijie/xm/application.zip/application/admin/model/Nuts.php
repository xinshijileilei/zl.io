<?php
namespace app\admin\model;

use think\Model;

class Nuts extends Model{
    
}