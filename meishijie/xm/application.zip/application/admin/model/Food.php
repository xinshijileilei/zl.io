<?php
namespace app\admin\model;

use think\Model;

class Food extends Model{
    
}