<?php
namespace app\admin\model;

use think\Model;

class Condiment extends Model{
    
}