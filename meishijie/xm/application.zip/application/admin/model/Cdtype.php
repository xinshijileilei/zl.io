<?php
namespace app\admin\model;

use think\Model;

class Cdtype extends Model{
    
    
}