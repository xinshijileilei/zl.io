<?php
namespace app\admin\model;

use think\Model;

class Assist extends Model{
    
}