<?php
namespace app\admin\controller;

use app\admin\common\Base;
use app\admin\model\Pttype as PttypeModel;

class Pttype extends Base {
    
    /*
     * 1 烹调方法分类列表
     * 1.1参数：
     * 1.2功能：
     *        1.2.1 默认get请求渲染页面
     *        1.2.2 post(ajax)请求获取烹调方法类别列表
     * */
    public function Pttype() {
        // 1.get请求渲染页面
        if(request()->isGet()){
            // 获取所有烹调方法类别信息
            $pttypeList = PttypeModel::order('sort')->select();
            
            return $this->fetch("pt_type",["pttypeList"=>$pttypeList]);
        }
    }
    
    /*
     * 2 烹调方法分类添加操作
     * 2.1参数：
     * 2.2功能：
     *        2.2.1 完成分类添加功能
     * */
    public function pttypeadd() {
        if(request()->isGet()){
            $pttype_id = request()->param();
            $pttype = PttypeModel::get($pttype_id);
            return $this -> fetch("pt_type_add",["pttype"=>$pttype]);
        }else{
            // 接受分类信息
            $arr = request()->param();
            
            $pttype = new PttypeModel();
            // 插入
            $res = $pttype -> Acreate($arr);
            // 判断插入是否成功
            if($res){
                return json(['code'=>1,'msg'=>'新增成功']);
            }else{
                return json(['code'=>2,'msg'=>'新增失败']);
            }
        }
        
    }
    /*
     * 3 烹调方法分类删除操作
     * 3.1参数：pttype_id 烹调方法类别ID
     * 3.2功能：
     *      3.2.1 post请求删除学生信息
     * */
    public function pttypedel()
    {
        if(request()->isPost()){
            
            $pttype_id = request()->param("pttype_id");   // 类别id
            $res = PttypeModel::destroy($pttype_id);          // 删除
            
            if($res){
                return json(['code'=>1,'msg'=>'删除成功']);
            }else{
                return json(['code'=>2,'msg'=>'删除失败']);
            }
        }
    }
    
    /*
     * 4 烹调方法分类查看/修改操作
     * 4.1参数：pttype_id 烹调方法类别ID
     * 4.2功能：
     *      4.2.1 get请求渲染页面，返回分类信息
     *      4.2.2 post请求方式修改分类信息
     * */
    public function pttypedetail()
    {
        if(request()->isGet()){
            // 获取pttype_id
            $pttype_id = request()->param('pttype_id');
            // 根据pttype_id获取分类信息
            $pttype = PttypeModel::get($pttype_id);
            // 渲染页面并传递分类信息
            return $this->fetch("pt_type_detail",["pttype"=>$pttype]);
        }else{
            // 接受分类信息
            $arr = request()->param();
            unset($arr["file"]);
            // 更新
            $res = PttypeModel::update($arr);
            
            if($res){
                return json(['code'=>1,'msg'=>'修改成功']);
            }else{
                return json(['code'=>2,'msg'=>'修改失败']);
            }
        }
    }
    
    /*
     * 5 描述：添加文章页面，图片上传功能
     * 5.1 参数：
     * 5.2 功能：1.图片上传
     *
     * */
    public function img_upload()
    {
        // 接收图片
        $file = request()->file();
        // 移动位置
        $info = $file['file']->move(ROOT_PATH . 'public/static' . DS . 'uploads'. DS . 'Pttype_img');
        
        if($info){
            
            // 自动生成部分的路径->20190528/alsdkfj2l34lkdjfa.jpg
            $name_path =str_replace('\\',"/",$info->getSaveName());
            // 原图路径
            $imgpath = "/public/static/uploads/Pttype_img/".$name_path;
            
            /* 生成图片缩略图 */
            // 打开原图
            $image = \think\Image::open(ROOT_PATH . $imgpath);
            
            // 制作缩略图部分名称
            $filePart = substr($name_path,0,strpos($name_path, '.')).'thumb';
            $thumb = $filePart.".".$info->getExtension();
            
            // 缩略图路径
            $thumb_path = '/public/static/uploads/Pttype_img/'.$thumb;
            //将图片裁剪为100x100并保存为 thumb原名.?
            $res = $image->thumb(100,100,\think\Image::THUMB_CENTER)->save(ROOT_PATH.$thumb_path);
            
            //成功上传后 获取上传信息
            $result["code"] = '0';
            $result["msg"] = "上传成功";
            $result['data']["src"] = "/xm".$imgpath;
            $result["img_url"] = $imgpath;
            $result["thumb_url"] = $thumb_path;
        }else{
            // 上传失败获取错误信息
            $result["code"] = '2';
            $result["msg"] = "上传失败";
        }
        return json_encode($result);
    }
    
    
    
}